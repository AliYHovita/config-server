package com.configuration.confclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
