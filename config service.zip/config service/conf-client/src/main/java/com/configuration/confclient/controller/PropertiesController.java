package com.configuration.confclient.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("conf/api/")
public class PropertiesController {

    @Autowired
    private final Environment env;

    public PropertiesController(Environment env) {
        this.env = env;
    }

    @GetMapping("getProperties/test")
    public String getPropertiesTest() {
        return env.getProperty("test.name");
    }
}
