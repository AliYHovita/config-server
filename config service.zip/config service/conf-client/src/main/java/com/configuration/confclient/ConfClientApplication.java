package com.configuration.confclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfClientApplication.class, args);
	}

}
