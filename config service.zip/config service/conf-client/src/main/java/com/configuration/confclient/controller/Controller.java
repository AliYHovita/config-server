package com.configuration.confclient.controller;

import com.configuration.confclient.model.Person;
import com.configuration.confclient.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("conf/api/")
public class Controller {

    @Autowired
    private PersonRepository personRepository;

    @Autowired
    private Environment environment;

    @GetMapping("app/name")
    public String appName() {
        return environment.getProperty("welcome.message");
    }

    @PostMapping("save")
    public ResponseEntity<Person> save(@RequestParam("name") String name){
        Person person = new Person();
        person.setName(name);
        person.setProDetails(environment.getProperty("test.name"));
        personRepository.save(person);
        return new ResponseEntity<>(person,HttpStatus.OK);
    }
}
