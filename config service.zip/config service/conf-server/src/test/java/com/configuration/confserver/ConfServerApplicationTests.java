package com.configuration.confserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
