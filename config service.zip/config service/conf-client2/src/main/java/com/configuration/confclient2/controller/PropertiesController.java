package com.configuration.confclient2.controller;

import com.configuration.confclient2.model.User;
import com.configuration.confclient2.repository.UserRepository;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("conf/api/")
public class PropertiesController {

    private final UserRepository userRepository;

    private final Environment env;

    public PropertiesController(UserRepository userRepository, Environment env) {
        this.userRepository = userRepository;
        this.env = env;
    }

    @GetMapping("getProperties/test")
    public String getPropertiesTest() {
        return env.getProperty("test.name");
    }

    @PostMapping("save")
    public ResponseEntity<User> save(@RequestParam("username") String username){
        User user = new User();
        user.setUsername(username);
        user.setProDetails(env.getProperty("test.name"));
        userRepository.save(user);
        return new ResponseEntity<>(user, HttpStatus.OK);
    }

}
