package com.configuration.confclient2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfClient2Application {

	public static void main(String[] args) {
		SpringApplication.run(ConfClient2Application.class, args);
	}

}
